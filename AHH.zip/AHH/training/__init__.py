"""
Training module for the gesture recognition system.

This module contains utilities for collecting training data and training
the gesture classifier model.
""" 